package program.game.start;

public class Health {
    /**
     * Getters & Setters Health
     */
    private int Health;


    public int getHealth() {
        return Health;
    }

    public void setHealth(int health) {
        this.Health = Health;
    }
}